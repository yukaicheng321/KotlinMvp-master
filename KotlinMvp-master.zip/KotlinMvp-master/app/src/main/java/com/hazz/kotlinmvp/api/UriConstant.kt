package com.hazz.kotlinmvp.api

/**
 * Created by xuhao on 2017/11/16.
 */
object UrlConstant{
    const val BASE_URL = "http://baobab.kaiyanapp.com/api/"

}