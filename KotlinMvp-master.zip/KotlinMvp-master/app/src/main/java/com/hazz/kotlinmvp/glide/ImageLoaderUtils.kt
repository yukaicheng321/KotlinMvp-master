package com.hazz.kotlinmvp.glide

/**
 * Created by xuhao on 2017/11/27.
 * desc:
 */
object ImageLoaderUtils{
    init {

    }



}