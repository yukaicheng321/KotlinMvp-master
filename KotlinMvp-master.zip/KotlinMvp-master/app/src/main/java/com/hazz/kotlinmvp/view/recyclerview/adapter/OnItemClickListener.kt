package com.hazz.kotlinmvp.view.recyclerview.adapter

/**
 * Created by Xiho on 2017/2/23.
 * Description: Adapter条目的点击事件
 */
interface OnItemClickListener {

    fun onItemClick(obj: Any?, position: Int)
}
